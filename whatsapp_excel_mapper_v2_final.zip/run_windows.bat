@echo off
setlocal
cd /d %~dp0

where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python was not found. Install Python 3.11 or newer, then run this file again.
    pause
    exit /b 1
  )
  set "PYTHON_CMD=python"
) else (
  set "PYTHON_CMD=py"
)

if not exist .venv (
  %PYTHON_CMD% -m venv .venv
)
call .venv\Scripts\activate
python -m pip install --disable-pip-version-check -r requirements.txt
python launcher.py
