from __future__ import annotations

import io
import hashlib
import hmac
import json
import logging
import math
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, PlainTextResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from pydantic import BaseModel, ConfigDict, Field, field_validator
from starlette.middleware.gzip import GZipMiddleware

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.getenv("APP_DATA_DIR", str(BASE_DIR / "data"))).expanduser().resolve()
DB_PATH = DATA_DIR / "mapper.db"
APP_VERSION = "2.0.0"


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        return max(minimum, min(int(os.getenv(name, str(default))), maximum))
    except ValueError:
        return default


MAX_TEXT_LENGTH = env_int("APP_MAX_TEXT_LENGTH", 100_000, 1_000, 500_000)
MAX_RECORDS = env_int("APP_MAX_RECORDS", 200, 1, 1_000)
MAX_MAPPINGS = env_int("APP_MAX_MAPPINGS", 100, 1, 500)
MAX_EXPORT_ROWS = env_int("APP_MAX_EXPORT_ROWS", 5_000, 1, 20_000)
MAX_EXPORT_COLUMNS = env_int("APP_MAX_EXPORT_COLUMNS", 100, 1, 250)
MAX_INBOX_MESSAGES = env_int("APP_MAX_INBOX_MESSAGES", 100, 10, 500)
MAX_WEBHOOK_BYTES = env_int("APP_MAX_WEBHOOK_BYTES", 1_000_000, 100_000, 5_000_000)
WHATSAPP_VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
WHATSAPP_APP_SECRET = os.getenv("WHATSAPP_APP_SECRET", "")

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO").upper())
logger = logging.getLogger("whatsapp_excel_mapper")
DATA_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_COLUMNS = [
    ("Customer", "Text", []), ("Date", "Date", []), ("Item", "Text", []),
    ("Quantity", "Number", []), ("Unit", "Category", ["Bags", "Pieces", "Kg", "Ton", "Box", "Nos"]),
    ("Rate", "Currency", []), ("Amount", "Currency", []), ("Phone", "Phone", []),
    ("Email", "Email", []),
    ("Payment Status", "Category", ["Paid", "Pending", "Partial", "Cancelled"]),
    ("Notes", "Text", []),
]
ALIASES = {
    "customer": "Customer", "name": "Customer", "party": "Customer", "firm": "Customer",
    "client": "Customer", "buyer": "Customer", "customername": "Customer", "partyname": "Customer",
    "date": "Date", "dt": "Date", "item": "Item", "material": "Item", "product": "Item", "goods": "Item",
    "qty": "Quantity", "quantity": "Quantity", "qnty": "Quantity", "unit": "Unit", "uom": "Unit",
    "rate": "Rate", "price": "Rate", "unitprice": "Rate", "amount": "Amount", "total": "Amount",
    "value": "Amount", "amt": "Amount", "phone": "Phone", "mobile": "Phone", "contact": "Phone",
    "mob": "Phone", "telephone": "Phone", "email": "Email", "mail": "Email", "status": "Payment Status",
    "paymentstatus": "Payment Status", "payment": "Payment Status", "note": "Notes", "notes": "Notes",
    "remark": "Notes", "remarks": "Notes",
}
UNIT_ALIASES = {
    "bag": "Bags", "bags": "Bags", "pc": "Pieces", "pcs": "Pieces", "piece": "Pieces", "pieces": "Pieces",
    "kg": "Kg", "kgs": "Kg", "kilogram": "Kg", "kilograms": "Kg", "ton": "Ton", "tons": "Ton",
    "tonne": "Ton", "tonnes": "Ton", "box": "Box", "boxes": "Box", "nos": "Nos", "no": "Nos",
}
DATA_TYPES = [
    "Auto", "Text", "Number", "Integer", "Currency", "Percentage", "Date", "Date & Time",
    "Phone", "Email", "Category", "Yes / No", "Ignore",
]


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def clean_name(value: str, label: str) -> str:
    cleaned = " ".join(value.strip().split())
    if not cleaned:
        raise ValueError(f"{label} cannot be blank")
    if any(ord(char) < 32 for char in cleaned):
        raise ValueError(f"{label} contains unsupported control characters")
    return cleaned


def clean_categories(values: list[str]) -> list[str]:
    cleaned: list[str] = []
    seen: set[str] = set()
    for value in values:
        category = clean_name(str(value), "Category")
        key = norm(category)
        if key and key not in seen:
            cleaned.append(category)
            seen.add(key)
    return cleaned


class APIModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ParseRequest(APIModel):
    text: str = Field(min_length=1, max_length=MAX_TEXT_LENGTH)

    @field_validator("text")
    @classmethod
    def non_blank_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Text cannot be blank")
        return value


class MappingItem(APIModel):
    source_field: str = Field(min_length=1, max_length=80)
    target_column: str = Field(min_length=1, max_length=80)
    data_type: str = Field(default="Text", min_length=1, max_length=30)
    categories: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("source_field")
    @classmethod
    def valid_source_field(cls, value: str) -> str:
        value = clean_name(value, "Source field")
        if not norm(value):
            raise ValueError("Source field needs at least one letter or number")
        return value

    @field_validator("target_column")
    @classmethod
    def valid_target_column(cls, value: str) -> str:
        return clean_name(value, "Target column")

    @field_validator("categories")
    @classmethod
    def valid_categories(cls, value: list[str]) -> list[str]:
        return clean_categories(value)


class ValidateRequest(APIModel):
    records: list[dict[str, Any]] = Field(min_length=1, max_length=MAX_RECORDS)
    mappings: list[MappingItem] = Field(min_length=1, max_length=MAX_MAPPINGS)


class ExportRequest(APIModel):
    rows: list[dict[str, Any]] = Field(min_length=1, max_length=MAX_EXPORT_ROWS)
    columns: list[str] = Field(min_length=1, max_length=MAX_EXPORT_COLUMNS)
    filename: str = Field(default="whatsapp_excel_import.xlsx", max_length=128)
    message_ids: list[int] = Field(default_factory=list, max_length=MAX_RECORDS)

    @field_validator("columns")
    @classmethod
    def valid_columns(cls, values: list[str]) -> list[str]:
        columns = [clean_name(str(value), "Column name") for value in values]
        if len({column.casefold() for column in columns}) != len(columns):
            raise ValueError("Excel columns must be unique")
        return columns

    @field_validator("filename")
    @classmethod
    def valid_filename(cls, value: str) -> str:
        return value.strip() or "whatsapp_excel_import.xlsx"

    @field_validator("message_ids")
    @classmethod
    def valid_message_ids(cls, values: list[int]) -> list[int]:
        if any(value < 1 for value in values):
            raise ValueError("Message IDs must be positive")
        return list(dict.fromkeys(values))


class DemoInboxRequest(APIModel):
    sender: str = Field(default="919999999999", min_length=7, max_length=32)
    contact_name: str = Field(default="Demo customer", max_length=80)
    text: str = Field(min_length=1, max_length=MAX_TEXT_LENGTH)

    @field_validator("sender")
    @classmethod
    def valid_sender(cls, value: str) -> str:
        digits = re.sub(r"\D", "", value)
        if len(digits) < 7:
            raise ValueError("Sender number looks too short")
        return digits

    @field_validator("contact_name")
    @classmethod
    def valid_contact_name(cls, value: str) -> str:
        return clean_name(value, "Contact name")

    @field_validator("text")
    @classmethod
    def valid_demo_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Message text cannot be blank")
        return value


class ColumnRequest(APIModel):
    name: str = Field(min_length=1, max_length=80)
    data_type: str = Field(default="Text", min_length=1, max_length=30)
    categories: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("name")
    @classmethod
    def valid_name(cls, value: str) -> str:
        return clean_name(value, "Column name")

    @field_validator("categories")
    @classmethod
    def valid_column_categories(cls, value: list[str]) -> list[str]:
        return clean_categories(value)


class MappingSaveRequest(APIModel):
    mappings: list[MappingItem] = Field(min_length=1, max_length=MAX_MAPPINGS)


class ColumnRule(APIModel):
    column: str = Field(min_length=1, max_length=80)
    data_type: str = Field(default="Text", min_length=1, max_length=30)
    categories: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("column")
    @classmethod
    def valid_rule_column(cls, value: str) -> str:
        return clean_name(value, "Column name")

    @field_validator("categories")
    @classmethod
    def valid_rule_categories(cls, value: list[str]) -> list[str]:
        return clean_categories(value)


class ReviewValidationRequest(APIModel):
    rows: list[dict[str, Any]] = Field(min_length=1, max_length=MAX_EXPORT_ROWS)
    columns: list[str] = Field(min_length=1, max_length=MAX_EXPORT_COLUMNS)
    rules: list[ColumnRule] = Field(min_length=1, max_length=MAX_EXPORT_COLUMNS)

    @field_validator("columns")
    @classmethod
    def valid_review_columns(cls, values: list[str]) -> list[str]:
        columns = [clean_name(str(value), "Column name") for value in values]
        if len({column.casefold() for column in columns}) != len(columns):
            raise ValueError("Review columns must be unique")
        return columns


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


def decode_categories(raw: str | None) -> list[str]:
    try:
        parsed = json.loads(raw or "[]")
    except (TypeError, json.JSONDecodeError):
        logger.warning("Ignoring malformed category data in mapper database")
        return []
    return clean_categories([str(value) for value in parsed]) if isinstance(parsed, list) else []


def init_db() -> None:
    with connect_db() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS columns (
                name TEXT PRIMARY KEY, data_type TEXT NOT NULL DEFAULT 'Text',
                categories_json TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS mappings (
                source_key TEXT PRIMARY KEY, source_label TEXT NOT NULL, target_column TEXT NOT NULL,
                data_type TEXT NOT NULL, categories_json TEXT NOT NULL DEFAULT '[]',
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS inbox_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                external_id TEXT NOT NULL UNIQUE,
                source TEXT NOT NULL,
                sender TEXT NOT NULL,
                contact_name TEXT NOT NULL DEFAULT '',
                message_type TEXT NOT NULL DEFAULT 'text',
                body TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'new',
                received_at TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CHECK (source IN ('demo', 'whatsapp')),
                CHECK (status IN ('new', 'opened', 'exported', 'ignored'))
            );
            CREATE INDEX IF NOT EXISTS idx_inbox_messages_status_received
                ON inbox_messages(status, received_at DESC);
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL DEFAULT '',
                details_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_audit_events_created ON audit_events(created_at DESC);
            """
        )
        for name, dtype, categories in DEFAULT_COLUMNS:
            conn.execute(
                "INSERT OR IGNORE INTO columns(name, data_type, categories_json) VALUES (?, ?, ?)",
                (name, dtype, json.dumps(categories)),
            )
        conn.commit()


def get_columns() -> list[dict[str, Any]]:
    with connect_db() as conn:
        rows = conn.execute("SELECT name, data_type, categories_json FROM columns ORDER BY rowid").fetchall()
    return [
        {"name": row["name"], "data_type": row["data_type"], "categories": decode_categories(row["categories_json"])}
        for row in rows
    ]


def get_mappings() -> dict[str, dict[str, Any]]:
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT source_key, source_label, target_column, data_type, categories_json FROM mappings"
        ).fetchall()
    return {
        row["source_key"]: {
            "source_label": row["source_label"], "target_column": row["target_column"],
            "data_type": row["data_type"], "categories": decode_categories(row["categories_json"]),
        }
        for row in rows
    }


DEMO_INBOX_MESSAGES = [
    {
        "external_id": "demo-order-sharma-001",
        "sender": "919876543210",
        "contact_name": "Sharma Traders",
        "body": "Party: Sharma Traders\nDate: 07/09/2026\nMaterial: Cement\nQty: 25 bags\nRate: ₹420\nTotal: ₹10,500\nPayment Status: Pending",
    },
    {
        "external_id": "demo-order-gupta-001",
        "sender": "919812345678",
        "contact_name": "Gupta Hardware",
        "body": "Customer: Gupta Hardware\nDate: 07/09/2026\nProduct: Steel Rod\nQuantity: 12 pieces\nPrice: 850\nAmount: 10200\nPayment Status: Paid",
    },
    {
        "external_id": "demo-order-verma-001",
        "sender": "919900112233",
        "contact_name": "Verma Construction",
        "body": "Verma Construction\n30 bags cement rate 415 payment pending",
    },
]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def normalize_timestamp(value: Any) -> str:
    try:
        return datetime.fromtimestamp(int(str(value)), tz=timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    except (TypeError, ValueError, OverflowError):
        return utc_now()


def insert_audit(conn: sqlite3.Connection, action: str, entity_type: str, entity_id: str, details: dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO audit_events(action, entity_type, entity_id, details_json) VALUES (?, ?, ?, ?)",
        (action, entity_type, entity_id, json.dumps(details, ensure_ascii=False)),
    )


def add_inbox_message(
    *, external_id: str, source: str, sender: str, contact_name: str, body: str,
    received_at: str, message_type: str = "text"
) -> int | None:
    if source not in {"demo", "whatsapp"}:
        raise ValueError("Unsupported message source")
    sender = re.sub(r"\D", "", sender)
    if len(sender) < 7 or not body.strip() or len(body) > MAX_TEXT_LENGTH:
        return None
    with connect_db() as conn:
        try:
            cursor = conn.execute(
                """
                INSERT INTO inbox_messages(external_id, source, sender, contact_name, message_type, body, status, received_at)
                VALUES (?, ?, ?, ?, ?, ?, 'new', ?)
                """,
                (external_id, source, sender, contact_name[:80], message_type[:30], body.strip(), received_at),
            )
        except sqlite3.IntegrityError:
            return None
        message_id = int(cursor.lastrowid)
        insert_audit(conn, "inbox.received", "inbox_message", str(message_id), {"source": source, "sender": sender})
        conn.commit()
    return message_id


def inbox_summary(conn: sqlite3.Connection) -> dict[str, int]:
    summary = {"all": 0, "new": 0, "opened": 0, "exported": 0, "ignored": 0}
    for row in conn.execute("SELECT status, COUNT(*) AS count FROM inbox_messages GROUP BY status").fetchall():
        summary[row["status"]] = int(row["count"])
        summary["all"] += int(row["count"])
    return summary


def get_inbox_messages(status: str, query: str, limit: int) -> tuple[list[dict[str, Any]], dict[str, int]]:
    where: list[str] = []
    params: list[Any] = []
    if status != "all":
        where.append("status = ?")
        params.append(status)
    if query:
        where.append("(sender LIKE ? OR contact_name LIKE ? OR body LIKE ?)")
        params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])
    condition = f"WHERE {' AND '.join(where)}" if where else ""
    with connect_db() as conn:
        rows = conn.execute(
            f"""SELECT id, source, sender, contact_name, message_type, body, status, received_at, created_at
                FROM inbox_messages {condition} ORDER BY received_at DESC, id DESC LIMIT ?""",
            (*params, limit),
        ).fetchall()
        summary = inbox_summary(conn)
    return [dict(row) for row in rows], summary


def get_inbox_message(message_id: int) -> dict[str, Any]:
    with connect_db() as conn:
        row = conn.execute(
            "SELECT id, source, sender, contact_name, message_type, body, status, received_at, created_at FROM inbox_messages WHERE id = ?",
            (message_id,),
        ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Inbox message was not found")
    return dict(row)


def update_inbox_status(message_ids: list[int], status: str, action: str) -> int:
    if not message_ids:
        return 0
    if status not in {"opened", "exported", "ignored"}:
        raise ValueError("Unsupported inbox status")
    placeholders = ", ".join("?" for _ in message_ids)
    with connect_db() as conn:
        cursor = conn.execute(
            f"UPDATE inbox_messages SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id IN ({placeholders})",
            (status, *message_ids),
        )
        for message_id in message_ids:
            insert_audit(conn, action, "inbox_message", str(message_id), {"status": status})
        conn.commit()
    return cursor.rowcount


def whatsapp_status() -> dict[str, Any]:
    configured = bool(WHATSAPP_VERIFY_TOKEN and WHATSAPP_APP_SECRET)
    return {
        "mode": "connected" if configured else "test",
        "configured": configured,
        "webhook_path": "/api/webhooks/whatsapp",
        "needs_verify_token": not bool(WHATSAPP_VERIFY_TOKEN),
        "needs_app_secret": not bool(WHATSAPP_APP_SECRET),
    }


def valid_whatsapp_signature(body: bytes, signature: str | None) -> bool:
    if not WHATSAPP_APP_SECRET or not signature:
        return False
    expected = "sha256=" + hmac.new(WHATSAPP_APP_SECRET.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def ingest_whatsapp_payload(payload: dict[str, Any]) -> dict[str, int]:
    result = {"accepted": 0, "duplicates": 0, "ignored": 0}
    for entry in payload.get("entry", []):
        if not isinstance(entry, dict):
            continue
        for change in entry.get("changes", []):
            if not isinstance(change, dict):
                continue
            value = change.get("value", {})
            if not isinstance(value, dict):
                continue
            contacts: dict[str, str] = {}
            for contact in value.get("contacts", []):
                if not isinstance(contact, dict):
                    continue
                profile = contact.get("profile")
                contacts[str(contact.get("wa_id", ""))] = str(profile.get("name", "") if isinstance(profile, dict) else "")[:80]
            for message in value.get("messages", []):
                if not isinstance(message, dict) or message.get("type") != "text":
                    result["ignored"] += 1
                    continue
                text = message.get("text", {}).get("body", "")
                sender = str(message.get("from", ""))
                if not isinstance(text, str) or not text.strip() or not sender:
                    result["ignored"] += 1
                    continue
                external_id = str(message.get("id") or hashlib.sha256(f"{sender}:{text}:{message.get('timestamp', '')}".encode()).hexdigest())
                message_id = add_inbox_message(
                    external_id=external_id,
                    source="whatsapp",
                    sender=sender,
                    contact_name=contacts.get(sender, ""),
                    body=text,
                    received_at=normalize_timestamp(message.get("timestamp")),
                )
                if message_id is None:
                    result["duplicates"] += 1
                else:
                    result["accepted"] += 1
    return result


def infer_type(field: str, values: list[str]) -> str:
    key = norm(field)
    sample = next((str(value).strip() for value in values if str(value).strip()), "")
    if any(token in key for token in ["phone", "mobile", "contact", "mob", "telephone"]):
        return "Phone"
    if "email" in key or key == "mail":
        return "Email"
    if "date" in key or key == "dt":
        return "Date"
    if "status" in key:
        return "Category"
    if any(token in key for token in ["amount", "total", "rate", "price", "amt"]):
        return "Currency"
    if key in {"qty", "quantity", "qnty"}:
        return "Number"
    if re.fullmatch(r"[+-]?\d[\d,]*(?:\.\d+)?%", sample):
        return "Percentage"
    return "Text"


def clean_field_label(value: str) -> str:
    return re.sub(r"^[*_~`]+|[*_~`]+$", "", value.strip()).strip()


def parse_key_value_lines(block: str) -> tuple[dict[str, str], list[str]]:
    record: dict[str, str] = {}
    leftovers: list[str] = []
    for raw_line in block.splitlines():
        line = raw_line.strip().lstrip("•*- ").strip()
        if not line:
            continue
        match = re.match(r"^([^:=]{1,60})\s*[:=]\s*(.+)$", line)
        if not match:
            match = re.match(r"^([A-Za-z][A-Za-z0-9 /_]{1,40})\s+-\s+(.+)$", line)
        if not match:
            leftovers.append(line)
            continue
        key, value = clean_field_label(match.group(1)), match.group(2).strip()
        if not key or not value:
            leftovers.append(line)
        elif key in record:
            record[key] = f"{record[key]} | {value}"
        else:
            record[key] = value
    return record, leftovers


def heuristic_extract(lines: list[str], existing: dict[str, str]) -> dict[str, str]:
    """Offline pattern extraction for common unlabelled message fragments."""
    result = dict(existing)
    text = " | ".join(lines)

    def missing(target: str) -> bool:
        return not any(ALIASES.get(norm(key)) == target for key in result)

    if missing("Phone"):
        match = re.search(r"(?<!\d)(\+?\d[\d\s()-]{7,}\d)(?!\d)", text)
        if match:
            result["Phone"] = match.group(1).strip()
    if missing("Email"):
        match = re.search(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b", text)
        if match:
            result["Email"] = match.group(0)
    if missing("Date"):
        match = re.search(r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{1,2}-\d{1,2})\b", text)
        if match:
            result["Date"] = match.group(1)
    if missing("Payment Status"):
        match = re.search(r"\b(paid|pending|partial|partially paid|cancelled|canceled)\b", text, re.I)
        if match:
            result["Payment Status"] = {
                "paid": "Paid", "pending": "Pending", "partial": "Partial", "partially paid": "Partial",
                "cancelled": "Cancelled", "canceled": "Cancelled",
            }[match.group(1).lower()]
    if missing("Rate"):
        match = re.search(r"\b(?:rate|price)\s*(?:is|=|:|@)?\s*[₹$€£]?\s*([\d,]+(?:\.\d+)?)", text, re.I)
        if not match:
            match = re.search(r"@\s*[₹$€£]?\s*([\d,]+(?:\.\d+)?)", text)
        if match:
            result["Rate"] = match.group(1)
    if missing("Amount"):
        match = re.search(r"\b(?:total|amount|amt)\s*(?:is|=|:)?\s*[₹$€£]?\s*([\d,]+(?:\.\d+)?)", text, re.I)
        if match:
            result["Amount"] = match.group(1)
    if missing("Quantity"):
        match = re.search(
            r"\b(\d+(?:\.\d+)?)\s*(bags?|pcs?|pieces?|kgs?|kilograms?|tons?|tonnes?|boxes?|nos?)\b", text, re.I
        )
        if match:
            result["Quantity"] = match.group(1)
            result.setdefault("Unit", UNIT_ALIASES.get(match.group(2).lower(), match.group(2).title()))
    if missing("Unit"):
        quantity_value = next(
            (str(value) for key, value in result.items() if ALIASES.get(norm(key)) == "Quantity"),
            "",
        )
        match = re.search(r"\b(?:\d+(?:\.\d+)?)\s*(bags?|pcs?|pieces?|kgs?|kilograms?|tons?|tonnes?|boxes?|nos?)\b", quantity_value, re.I)
        if match:
            result["Unit"] = UNIT_ALIASES.get(match.group(1).lower(), match.group(1).title())
    if missing("Customer") and lines:
        first = lines[0]
        if len(first) <= 80 and not re.search(r"\d{4,}|@|\b(rate|qty|quantity|total|amount|paid|pending)\b", first, re.I):
            result["Customer"] = first
            lines = lines[1:]
    if lines:
        remaining = " | ".join(lines)
        if remaining and remaining not in result.values():
            result["Notes"] = remaining
    return result


def parse_text(text: str) -> list[dict[str, str]]:
    cleaned = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    blocks = [block.strip() for block in re.split(r"\n\s*\n+", cleaned) if block.strip()]
    if len(blocks) > MAX_RECORDS:
        raise ValueError(f"A maximum of {MAX_RECORDS} records can be processed at once.")
    records: list[dict[str, str]] = []
    for block in blocks:
        record, leftovers = parse_key_value_lines(block)
        record = heuristic_extract(leftovers, record)
        if record:
            records.append(record)
    return records


def number_from(value: Any) -> float | None:
    match = re.search(r"[+-]?\d+(?:\.\d+)?", str(value).replace(",", ""))
    if not match:
        return None
    try:
        number = float(match.group(0))
    except (ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


DATE_FORMATS = ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%y", "%d-%m-%y"]
DATETIME_FORMATS = [
    "%d/%m/%Y %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %I:%M %p", "%d-%m-%Y %H:%M",
    "%d-%m-%Y %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %I:%M %p",
]


def parse_datetime(value: str, require_time: bool) -> datetime | None:
    candidate = " ".join(value.replace("T", " ").split())
    for fmt in DATETIME_FORMATS + ([] if require_time else DATE_FORMATS):
        try:
            return datetime.strptime(candidate, fmt)
        except ValueError:
            continue
    return None


def transform_value(value: Any, data_type: str, categories: list[str]) -> tuple[Any, bool, str | None]:
    original = "" if value is None else str(value).strip()
    if not original:
        return "", True, None
    if data_type in {"Text", "Auto"}:
        if data_type == "Auto":
            if re.fullmatch(r"\S+@\S+\.\S+", original):
                return original, True, None
            if re.fullmatch(r"[₹$€£]?\s*[+-]?[\d,.]+", original):
                number = number_from(original)
                return (number if number is not None else original), True, None
        return original, True, None
    if data_type == "Ignore":
        return "", True, None
    if data_type == "Number":
        number = number_from(original)
        return (number, True, None) if number is not None else (original, False, "Not a valid number")
    if data_type == "Integer":
        number = number_from(original)
        if number is None or not number.is_integer():
            return original, False, "Expected a whole number"
        return int(number), True, None
    if data_type == "Currency":
        number = number_from(original)
        return (number, True, None) if number is not None else (original, False, "Could not read the currency amount")
    if data_type == "Percentage":
        number = number_from(original)
        return (number / 100.0, True, None) if number is not None else (original, False, "Could not read the percentage")
    if data_type == "Phone":
        plus = "+" if original.startswith("+") else ""
        digits = re.sub(r"\D", "", original)
        if len(digits) < 7:
            return original, False, "Phone number looks too short"
        return plus + digits, True, None
    if data_type == "Email":
        valid = bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", original))
        return original, valid, None if valid else "Invalid email format"
    if data_type == "Yes / No":
        key = norm(original)
        if key in {"yes", "y", "true", "1"}:
            return "Yes", True, None
        if key in {"no", "n", "false", "0"}:
            return "No", True, None
        return original, False, "Expected Yes or No"
    if data_type in {"Date", "Date & Time"}:
        parsed = parse_datetime(original, require_time=data_type == "Date & Time")
        if not parsed:
            hint = "DD/MM/YYYY HH:MM" if data_type == "Date & Time" else "DD/MM/YYYY"
            return original, False, f"Date format not understood (try {hint})"
        return (parsed.strftime("%Y-%m-%d %H:%M") if data_type == "Date & Time" else parsed.strftime("%Y-%m-%d")), True, None
    if data_type == "Category":
        allowed = clean_categories(categories)
        if not allowed:
            return original, False, "No allowed category values were configured"
        matched = next((item for item in allowed if norm(item) == norm(original)), None)
        return (matched, True, None) if matched else (original, False, f"Unknown category; allowed: {', '.join(allowed)}")
    return original, True, None


def suggested_mapping(field: str, values: list[str], saved: dict[str, dict[str, Any]], columns: list[dict[str, Any]]) -> dict[str, Any]:
    key = norm(field)
    valid_columns = {column["name"] for column in columns} | {"Ignore"}
    if key in saved and saved[key]["target_column"] in valid_columns and saved[key]["data_type"] in DATA_TYPES:
        item = saved[key]
        return {"source_field": field, "target_column": item["target_column"], "data_type": item["data_type"], "categories": item["categories"], "reason": "remembered"}
    target = ALIASES.get(key, "Notes")
    column_info = next((column for column in columns if column["name"] == target), None)
    data_type = infer_type(field, values)
    if column_info and data_type == "Text" and column_info["data_type"] not in {"Text", "Auto", "Ignore"}:
        data_type = column_info["data_type"]
    return {
        "source_field": field, "target_column": target, "data_type": data_type,
        "categories": column_info["categories"] if column_info and data_type == "Category" else [], "reason": "suggested",
    }


def parse_workspace_text(text: str) -> dict[str, Any]:
    try:
        records = parse_text(text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not records:
        raise HTTPException(status_code=422, detail="No usable records were found in the message text.")
    fields = list(dict.fromkeys(key for record in records for key in record))
    columns, saved = get_columns(), get_mappings()
    suggestions = [
        suggested_mapping(field, [str(record.get(field, "")) for record in records], saved, columns)
        for field in fields
    ]
    return {"records": records, "fields": fields, "suggestions": suggestions}


def validate_mapping_definitions(mappings: list[MappingItem]) -> None:
    valid_columns = {column["name"] for column in get_columns()} | {"Ignore"}
    seen_fields: set[str] = set()
    for mapping in mappings:
        source_key = norm(mapping.source_field)
        if source_key in seen_fields:
            raise HTTPException(status_code=422, detail="Each source field can only be mapped once.")
        seen_fields.add(source_key)
        if mapping.target_column not in valid_columns:
            raise HTTPException(status_code=422, detail=f"Unknown target column: {mapping.target_column}")
        if mapping.data_type not in DATA_TYPES:
            raise HTTPException(status_code=422, detail=f"Unknown data type: {mapping.data_type}")
        if mapping.target_column != "Ignore" and mapping.data_type == "Category" and not mapping.categories:
            raise HTTPException(status_code=422, detail=f"Category mapping for {mapping.source_field} needs allowed values.")


def validate_review_rules(columns: list[str], rules: list[ColumnRule]) -> dict[str, ColumnRule]:
    valid_columns = {column["name"] for column in get_columns()}
    if any(column not in valid_columns for column in columns):
        raise HTTPException(status_code=422, detail="One or more review columns no longer exist.")
    rules_by_column: dict[str, ColumnRule] = {}
    for rule in rules:
        if rule.column not in columns:
            raise HTTPException(status_code=422, detail=f"Unexpected review rule: {rule.column}")
        if rule.column in rules_by_column:
            raise HTTPException(status_code=422, detail=f"Duplicate review rule: {rule.column}")
        if rule.data_type not in DATA_TYPES or rule.data_type == "Ignore":
            raise HTTPException(status_code=422, detail=f"Invalid data type for {rule.column}")
        if rule.data_type == "Category" and not rule.categories:
            raise HTTPException(status_code=422, detail=f"Category column {rule.column} needs allowed values.")
        rules_by_column[rule.column] = rule
    if set(rules_by_column) != set(columns):
        raise HTTPException(status_code=422, detail="Each review column needs exactly one validation rule.")
    return rules_by_column


def review_rows(rows: list[dict[str, Any]], columns: list[str], rules_by_column: dict[str, ColumnRule]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    checked_rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    for row_index, row in enumerate(rows, start=1):
        checked_row: dict[str, Any] = {}
        for column in columns:
            rule = rules_by_column[column]
            raw_value = row.get(column, "")
            value, valid, message = transform_value(raw_value, rule.data_type, rule.categories)
            checked_row[column] = value
            if not valid:
                issues.append({"row": row_index, "source_field": "Reviewed value", "target_column": column, "original_value": raw_value, "message": message})
        checked_rows.append(checked_row)
    return checked_rows, issues


def safe_excel_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float) and not math.isfinite(value):
        return ""
    if isinstance(value, str):
        return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value
    if isinstance(value, (int, float, bool, datetime)):
        return value
    return json.dumps(value, ensure_ascii=False)


def safe_export_filename(filename: str) -> str:
    candidate = re.sub(r"[^A-Za-z0-9._-]", "_", filename).strip("._") or "whatsapp_excel_import"
    if candidate.lower().endswith(".xlsx"):
        return candidate[:128]
    return f"{candidate[:123]}.xlsx"


init_db()
app = FastAPI(title="Smart WhatsApp to Excel Mapper", version=APP_VERSION)
app.add_middleware(GZipMiddleware, minimum_size=500)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.middleware("http")
async def add_response_headers(request: Request, call_next: Any) -> Any:
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'")
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


@app.get("/")
def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/healthz", include_in_schema=False)
def healthz() -> dict[str, str]:
    try:
        with connect_db() as conn:
            conn.execute("SELECT 1").fetchone()
    except sqlite3.Error as exc:
        logger.exception("Health check failed")
        raise HTTPException(status_code=503, detail="Database is unavailable") from exc
    return {"status": "ok", "version": APP_VERSION}


@app.get("/api/config")
def config() -> dict[str, Any]:
    return {
        "columns": get_columns(),
        "data_types": DATA_TYPES,
        "saved_mapping_count": len(get_mappings()),
        "limits": {"max_records": MAX_RECORDS, "max_export_rows": MAX_EXPORT_ROWS},
        "whatsapp": whatsapp_status(),
        "version": APP_VERSION,
    }


@app.get("/api/inbox")
def list_inbox(
    status: str = Query("all", max_length=12),
    q: str = Query("", max_length=100),
    limit: int = Query(50, ge=1, le=MAX_INBOX_MESSAGES),
) -> dict[str, Any]:
    if status not in {"all", "new", "opened", "exported", "ignored"}:
        raise HTTPException(status_code=422, detail="Invalid inbox status")
    messages, summary = get_inbox_messages(status, q.strip(), limit)
    return {"messages": messages, "summary": summary}


@app.post("/api/inbox/demo")
def seed_demo_inbox() -> dict[str, Any]:
    added = 0
    for message in DEMO_INBOX_MESSAGES:
        if add_inbox_message(source="demo", received_at=utc_now(), message_type="text", **message):
            added += 1
    return {"ok": True, "added": added, "message": "Demo messages are ready in the inbox" if added else "Demo messages are already in the inbox"}


@app.post("/api/inbox/demo/custom")
def add_demo_inbox_message(req: DemoInboxRequest) -> dict[str, Any]:
    nonce = os.urandom(12).hex()
    message_id = add_inbox_message(
        external_id=f"demo-{nonce}",
        source="demo",
        sender=req.sender,
        contact_name=req.contact_name,
        body=req.text,
        received_at=utc_now(),
    )
    if message_id is None:
        raise HTTPException(status_code=422, detail="The demo message could not be stored")
    return {"ok": True, "message_id": message_id}


@app.post("/api/inbox/{message_id}/prepare")
def prepare_inbox_message(message_id: int) -> dict[str, Any]:
    message = get_inbox_message(message_id)
    parsed = parse_workspace_text(message["body"])
    if message["status"] != "exported":
        update_inbox_status([message_id], "opened", "inbox.opened")
    parsed["source_message"] = {key: message[key] for key in ("id", "source", "sender", "contact_name", "received_at")}
    parsed["raw_text"] = message["body"]
    return parsed


@app.post("/api/inbox/{message_id}/ignore")
def ignore_inbox_message(message_id: int) -> dict[str, Any]:
    get_inbox_message(message_id)
    update_inbox_status([message_id], "ignored", "inbox.ignored")
    return {"ok": True}


@app.get("/api/webhooks/whatsapp", include_in_schema=False)
def verify_whatsapp_webhook(
    hub_mode: str | None = Query(None, alias="hub.mode"),
    hub_verify_token: str | None = Query(None, alias="hub.verify_token"),
    hub_challenge: str | None = Query(None, alias="hub.challenge"),
) -> PlainTextResponse:
    if not WHATSAPP_VERIFY_TOKEN:
        raise HTTPException(status_code=503, detail="WhatsApp webhook verification is not configured")
    if hub_mode == "subscribe" and hub_verify_token and hmac.compare_digest(hub_verify_token, WHATSAPP_VERIFY_TOKEN):
        return PlainTextResponse(hub_challenge or "")
    raise HTTPException(status_code=403, detail="Webhook verification failed")


@app.post("/api/webhooks/whatsapp", include_in_schema=False)
async def receive_whatsapp_webhook(request: Request) -> dict[str, Any]:
    if not WHATSAPP_VERIFY_TOKEN or not WHATSAPP_APP_SECRET:
        raise HTTPException(status_code=503, detail="WhatsApp webhook is not configured")
    body = await request.body()
    if len(body) > MAX_WEBHOOK_BYTES:
        raise HTTPException(status_code=413, detail="Webhook payload is too large")
    if not valid_whatsapp_signature(body, request.headers.get("X-Hub-Signature-256")):
        raise HTTPException(status_code=401, detail="Webhook signature is invalid")
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="Webhook body is not valid JSON") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Webhook payload must be an object")
    result = ingest_whatsapp_payload(payload)
    with connect_db() as conn:
        insert_audit(conn, "webhook.received", "whatsapp", "", result)
        conn.commit()
    return {"ok": True, **result}


@app.post("/api/parse")
def parse(req: ParseRequest) -> dict[str, Any]:
    return parse_workspace_text(req.text)


@app.post("/api/columns")
def add_column(req: ColumnRequest) -> dict[str, Any]:
    if req.data_type not in DATA_TYPES or req.data_type == "Ignore":
        raise HTTPException(status_code=422, detail="Invalid default data type")
    with connect_db() as conn:
        if conn.execute("SELECT 1 FROM columns WHERE name = ? COLLATE NOCASE", (req.name,)).fetchone():
            raise HTTPException(status_code=409, detail="That column already exists")
        conn.execute("INSERT INTO columns(name, data_type, categories_json) VALUES (?, ?, ?)", (req.name, req.data_type, json.dumps(req.categories)))
        conn.commit()
    return {"ok": True, "columns": get_columns()}


@app.post("/api/mappings/save")
def save_mappings(req: MappingSaveRequest) -> dict[str, Any]:
    validate_mapping_definitions(req.mappings)
    with connect_db() as conn:
        for mapping in req.mappings:
            conn.execute(
                """
                INSERT INTO mappings(source_key, source_label, target_column, data_type, categories_json, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(source_key) DO UPDATE SET source_label=excluded.source_label,
                target_column=excluded.target_column, data_type=excluded.data_type,
                categories_json=excluded.categories_json, updated_at=CURRENT_TIMESTAMP
                """,
                (norm(mapping.source_field), mapping.source_field, mapping.target_column, mapping.data_type, json.dumps(mapping.categories)),
            )
        conn.commit()
    return {"ok": True, "saved_mapping_count": len(get_mappings())}


@app.delete("/api/mappings")
def clear_mappings() -> dict[str, Any]:
    with connect_db() as conn:
        conn.execute("DELETE FROM mappings")
        conn.commit()
    return {"ok": True}


@app.post("/api/validate")
def validate(req: ValidateRequest) -> dict[str, Any]:
    validate_mapping_definitions(req.mappings)
    mappings = {mapping.source_field: mapping for mapping in req.mappings}
    used_columns: list[str] = []
    for mapping in req.mappings:
        if mapping.target_column != "Ignore" and mapping.data_type != "Ignore" and mapping.target_column not in used_columns:
            used_columns.append(mapping.target_column)
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    for row_index, record in enumerate(req.records, start=1):
        output = {column: "" for column in used_columns}
        for source_field, raw_value in record.items():
            mapping = mappings.get(source_field)
            if not mapping or mapping.target_column == "Ignore" or mapping.data_type == "Ignore":
                continue
            value, valid, message = transform_value(raw_value, mapping.data_type, mapping.categories)
            current = output.get(mapping.target_column, "")
            if current not in {"", None} and value not in {"", None} and str(current) != str(value):
                output[mapping.target_column] = f"{current} | {value}"
                issues.append({"row": row_index, "source_field": source_field, "target_column": mapping.target_column, "original_value": raw_value, "message": "Multiple different values were mapped to the same Excel column"})
            elif current in {"", None}:
                output[mapping.target_column] = value
            if not valid:
                issues.append({"row": row_index, "source_field": source_field, "target_column": mapping.target_column, "original_value": raw_value, "message": message})
        rows.append(output)
    return {"columns": used_columns, "rows": rows, "issues": issues}


@app.post("/api/review/validate")
def validate_review(req: ReviewValidationRequest) -> dict[str, Any]:
    rules_by_column = validate_review_rules(req.columns, req.rules)
    rows, issues = review_rows(req.rows, req.columns, rules_by_column)
    return {"columns": req.columns, "rows": rows, "issues": issues}


@app.post("/api/export")
def export_excel(req: ExportRequest) -> StreamingResponse:
    if not set(req.columns).issubset({column["name"] for column in get_columns()}):
        raise HTTPException(status_code=422, detail="One or more export columns no longer exist.")
    if req.message_ids:
        placeholders = ", ".join("?" for _ in req.message_ids)
        with connect_db() as conn:
            existing_ids = {row["id"] for row in conn.execute(f"SELECT id FROM inbox_messages WHERE id IN ({placeholders})", req.message_ids).fetchall()}
        if existing_ids != set(req.message_ids):
            raise HTTPException(status_code=422, detail="One or more source messages no longer exist.")
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Imported Data"
    worksheet.sheet_view.showGridLines = False
    worksheet.append([safe_excel_value(column) for column in req.columns])
    header_fill = PatternFill("solid", fgColor="176B5B")
    for cell in worksheet[1]:
        cell.font, cell.fill = Font(bold=True, color="FFFFFF"), header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for row in req.rows:
        worksheet.append([safe_excel_value(row.get(column, "")) for column in req.columns])
    for index, column in enumerate(req.columns, start=1):
        values = [safe_excel_value(row.get(column, "")) for row in req.rows[:500]]
        max_length = max([len(str(column))] + [len(str(value)) for value in values])
        worksheet.column_dimensions[get_column_letter(index)].width = min(max(max_length + 2, 10), 40)
    worksheet.freeze_panes, worksheet.auto_filter.ref = "A2", worksheet.dimensions
    table = Table(displayName="ImportedData", ref=worksheet.dimensions)
    table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium4", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    worksheet.add_table(table)
    output = io.BytesIO()
    workbook.save(output)
    output.seek(0)
    if req.message_ids:
        update_inbox_status(req.message_ids, "exported", "inbox.exported")
    with connect_db() as conn:
        insert_audit(
            conn,
            "export.prepared",
            "workbook",
            safe_export_filename(req.filename),
            {"row_count": len(req.rows), "column_count": len(req.columns), "message_ids": req.message_ids},
        )
        conn.commit()
    return StreamingResponse(output, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{safe_export_filename(req.filename)}"'})
