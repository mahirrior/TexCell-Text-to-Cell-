import hashlib
import hmac
import json
import os
from io import BytesIO
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

os.environ.setdefault("APP_DATA_DIR", str(Path(__file__).parent / ".test-data"))

import app as mapper_app  # noqa: E402
from app import DEFAULT_COLUMNS, app, connect_db  # noqa: E402


client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_database():
    default_names = [column[0] for column in DEFAULT_COLUMNS]
    placeholders = ", ".join("?" for _ in default_names)
    with connect_db() as conn:
        conn.execute("DELETE FROM mappings")
        conn.execute(f"DELETE FROM columns WHERE name NOT IN ({placeholders})", default_names)
        conn.execute("DELETE FROM inbox_messages")
        conn.execute("DELETE FROM audit_events")
        conn.commit()
    yield


def standard_mappings():
    return [
        {"source_field": "Party", "target_column": "Customer", "data_type": "Text", "categories": []},
        {"source_field": "Date", "target_column": "Date", "data_type": "Date", "categories": []},
        {"source_field": "Qty", "target_column": "Quantity", "data_type": "Number", "categories": []},
        {"source_field": "Rate", "target_column": "Rate", "data_type": "Currency", "categories": []},
        {"source_field": "Payment Status", "target_column": "Payment Status", "data_type": "Category", "categories": ["Paid", "Pending", "Partial", "Cancelled"]},
    ]


def test_home_health_and_security_headers():
    response = client.get("/")
    assert response.status_code == 200
    assert "Smart Excel Mapper" in response.text
    assert "VERSION 2" in response.text
    assert "frame-ancestors 'none'" in response.headers["content-security-policy"]

    health = client.get("/healthz")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"


def test_v2_config_uses_safe_test_mode_without_exposing_secrets():
    response = client.get("/api/config")
    assert response.status_code == 200
    data = response.json()
    assert data["version"] == "2.0.0"
    assert data["whatsapp"]["mode"] == "test"
    assert data["whatsapp"]["configured"] is False
    assert "WHATSAPP_APP_SECRET" not in json.dumps(data)


def test_demo_inbox_prepare_export_and_audit_flow():
    seeded = client.post("/api/inbox/demo", json={})
    assert seeded.status_code == 200
    assert seeded.json()["added"] == 3

    inbox = client.get("/api/inbox?status=new").json()
    assert inbox["summary"]["all"] == 3
    assert len(inbox["messages"]) == 3
    message_id = inbox["messages"][0]["id"]

    prepared = client.post(f"/api/inbox/{message_id}/prepare", json={})
    assert prepared.status_code == 200
    prepared_data = prepared.json()
    assert prepared_data["source_message"]["id"] == message_id
    assert prepared_data["raw_text"]
    assert prepared_data["records"]

    export = client.post("/api/export", json={
        "rows": [{"Customer": "Demo", "Amount": 42}],
        "columns": ["Customer", "Amount"],
        "message_ids": [message_id],
    })
    assert export.status_code == 200
    updated = client.get("/api/inbox?status=exported").json()
    assert [message["id"] for message in updated["messages"]] == [message_id]
    with connect_db() as conn:
        actions = {row["action"] for row in conn.execute("SELECT action FROM audit_events").fetchall()}
    assert {"inbox.received", "inbox.opened", "inbox.exported", "export.prepared"}.issubset(actions)


def test_whatsapp_webhook_verification_signature_and_deduplication(monkeypatch):
    monkeypatch.setattr(mapper_app, "WHATSAPP_VERIFY_TOKEN", "verify-me")
    monkeypatch.setattr(mapper_app, "WHATSAPP_APP_SECRET", "app-secret")

    verified = client.get("/api/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=verify-me&hub.challenge=challenge-123")
    assert verified.status_code == 200
    assert verified.text == "challenge-123"

    payload = {
        "object": "whatsapp_business_account",
        "entry": [{"changes": [{"value": {
            "contacts": [{"wa_id": "919876543210", "profile": {"name": "Sharma Traders"}}],
            "messages": [{"from": "919876543210", "id": "wamid.test.1", "timestamp": "1788748200", "type": "text", "text": {"body": "Party: Sharma Traders\\nQty: 10 bags"}}],
        }}]}],
    }
    body = json.dumps(payload, separators=(",", ":")).encode()
    signature = "sha256=" + hmac.new(b"app-secret", body, hashlib.sha256).hexdigest()
    headers = {"Content-Type": "application/json", "X-Hub-Signature-256": signature}

    received = client.post("/api/webhooks/whatsapp", content=body, headers=headers)
    assert received.status_code == 200
    assert received.json()["accepted"] == 1
    duplicate = client.post("/api/webhooks/whatsapp", content=body, headers=headers)
    assert duplicate.status_code == 200
    assert duplicate.json()["duplicates"] == 1

    inbox = client.get("/api/inbox?q=Sharma").json()
    assert inbox["summary"]["all"] == 1
    assert inbox["messages"][0]["contact_name"] == "Sharma Traders"
    rejected = client.post("/api/webhooks/whatsapp", content=body, headers={"Content-Type": "application/json", "X-Hub-Signature-256": "sha256=wrong"})
    assert rejected.status_code == 401


def test_parse_suggest_validate_and_remember_mapping():
    text = "*Party*: Sharma Traders\nDate: 06/09/2026\nQty: 25 bags\nRate: ₹420\nPayment Status: Pending"
    parsed = client.post("/api/parse", json={"text": text})
    assert parsed.status_code == 200
    data = parsed.json()
    assert data["records"][0]["Party"] == "Sharma Traders"
    assert next(item for item in data["suggestions"] if item["source_field"] == "Unit")["data_type"] == "Category"

    mappings = standard_mappings()
    saved = client.post("/api/mappings/save", json={"mappings": mappings})
    assert saved.status_code == 200
    assert saved.json()["saved_mapping_count"] == len(mappings)

    checked = client.post("/api/validate", json={"records": data["records"], "mappings": mappings})
    assert checked.status_code == 200
    output = checked.json()
    assert output["rows"][0]["Customer"] == "Sharma Traders"
    assert output["rows"][0]["Date"] == "2026-09-06"
    assert output["rows"][0]["Quantity"] == 25.0
    assert output["rows"][0]["Rate"] == 420.0
    assert output["issues"] == []

    remembered = client.post("/api/parse", json={"text": text}).json()
    assert next(item for item in remembered["suggestions"] if item["source_field"] == "Party")["reason"] == "remembered"


def test_review_validation_blocks_bad_manual_edits_and_normalizes_datetime():
    payload = {
        "rows": [{"Date": "06/09/2026 14:30", "Quantity": "not a number", "Payment Status": "maybe"}],
        "columns": ["Date", "Quantity", "Payment Status"],
        "rules": [
            {"column": "Date", "data_type": "Date & Time", "categories": []},
            {"column": "Quantity", "data_type": "Number", "categories": []},
            {"column": "Payment Status", "data_type": "Category", "categories": ["Paid", "Pending"]},
        ],
    }
    invalid = client.post("/api/review/validate", json=payload)
    assert invalid.status_code == 200
    invalid_data = invalid.json()
    assert invalid_data["rows"][0]["Date"] == "2026-09-06 14:30"
    assert {issue["target_column"] for issue in invalid_data["issues"]} == {"Quantity", "Payment Status"}

    payload["rows"][0].update({"Quantity": "12", "Payment Status": "pending"})
    valid = client.post("/api/review/validate", json=payload)
    assert valid.status_code == 200
    assert valid.json()["issues"] == []
    assert valid.json()["rows"][0]["Payment Status"] == "Pending"


def test_export_excel_is_styled_and_formula_safe():
    response = client.post("/api/export", json={
        "rows": [{"Customer": "ABC", "Amount": 100, "Notes": "=HYPERLINK(\"https://example.com\",\"click\")"}],
        "columns": ["Customer", "Amount", "Notes"],
        "filename": "test export.xlsx",
    })
    assert response.status_code == 200
    assert response.content[:2] == b"PK"
    assert 'filename="test_export.xlsx"' in response.headers["content-disposition"]

    workbook = load_workbook(BytesIO(response.content), data_only=False)
    sheet = workbook["Imported Data"]
    assert sheet["A1"].font.bold is True
    assert sheet["C2"].value.startswith("'=")
    assert "ImportedData" in sheet.tables


def test_invalid_mapping_and_unknown_export_column_are_rejected():
    invalid = client.post("/api/mappings/save", json={
        "mappings": [{"source_field": "Status", "target_column": "Payment Status", "data_type": "Category", "categories": []}]
    })
    assert invalid.status_code == 422
    assert "needs allowed values" in invalid.json()["detail"]

    export = client.post("/api/export", json={"rows": [{"Unknown": "value"}], "columns": ["Unknown"]})
    assert export.status_code == 422
