# Smart WhatsApp → Excel Mapper V2

Version 2 is the final ready-to-connect project. It works immediately in **test inbox mode**, and it includes a secure WhatsApp Business webhook endpoint for real incoming messages once you add your own Meta credentials.

## What V2 does

- Receives and stores incoming message text in an inbox.
- Includes a fully working demo inbox, so no credentials are required to test the complete app.
- Prevents duplicate orders when WhatsApp resends the same webhook event.
- Lets you choose an inbox message, extract fields, map data, review values, and download a formatted Excel workbook.
- Marks source messages as **new**, **opened**, **exported**, or **ignored**.
- Keeps an audit record for message receipt, status changes, and Excel exports.
- Validates every manual change again before creating Excel.
- Protects Excel exports from formula injection.
- Verifies Meta webhook challenges and validates `X-Hub-Signature-256` signatures before accepting live messages.

## Run locally

Do **not** open `static/index.html` directly. This is a FastAPI web application and must be started through Python.

### Windows

1. Extract the ZIP.
2. Open the `whatsapp_excel_mapper` folder.
3. Double-click `run_windows.bat`.
4. Open `http://127.0.0.1:8000` if your browser does not open automatically.

### macOS / Linux

```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

### Manual start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python launcher.py
```

## Use V2 in test mode

1. Start the app and open `http://127.0.0.1:8000`.
2. In **Incoming message inbox**, select **Load V2 demo messages**.
3. Select **Use message** for an order.
4. Confirm the suggested field mappings, then select **Save mapping & review**.
5. Correct any highlighted value and select **Re-check values**.
6. Select **Download Excel**. The source inbox message changes to **exported**.

You can also paste WhatsApp text manually in Step 2.

## Connect real WhatsApp Business messages

The app already exposes these endpoints:

```text
GET  /api/webhooks/whatsapp   # Meta verification challenge
POST /api/webhooks/whatsapp   # signed incoming messages
```

Before connecting Meta, copy the example settings file and set your private values:

```bash
# macOS/Linux
cp .env.example .env

# Windows PowerShell
Copy-Item .env.example .env
```

In `.env`, set:

```text
WHATSAPP_VERIFY_TOKEN=your-own-long-random-token
WHATSAPP_APP_SECRET=your-meta-app-secret
```

Then restart the application. The top-right inbox badge changes from **Test inbox active** to **WhatsApp webhook connected** only when both values are present.

For Meta configuration, expose the running app through a secure public HTTPS domain and use this callback URL:

```text
https://your-domain.example/api/webhooks/whatsapp
```

Use the exact `WHATSAPP_VERIFY_TOKEN` as the webhook verification token in your Meta configuration. Keep `.env` private—never upload it to GitHub or send it in chat. Subscribe your WhatsApp Business app to incoming message events. Only signed text messages are stored; unsupported message types are ignored safely.

## Docker deployment

Docker stores the SQLite database in a named volume.

```bash
docker compose up --build -d
```

For live WhatsApp use, create `.env` first, then run the same command. Put the container behind an HTTPS reverse proxy and restrict access to authorised staff.

Check application health:

```bash
curl http://localhost:8000/healthz
```

## Tests

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
node --check static/app.js
```

The automated suite covers V1 mapping/export behavior plus V2 inbox handling, message-state updates, audit records, Meta challenge verification, HMAC signature validation, and webhook duplicate protection.

## Local data

Columns, mappings, inbox messages, and audit events are stored in `data/mapper.db` by default. Set `APP_DATA_DIR` in `.env` to use another writable location. Deleting the database resets all local app data.
