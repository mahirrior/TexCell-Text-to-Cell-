const state = {
  config: null, records: [], suggestions: [], cleanRows: [], columns: [], issues: [], rules: [],
  inbox: [], inboxSummary: {}, sourceMessageIds: [], sourceMessage: null
};

const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[char]));

function errorMessage(detail, fallback) {
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) return detail.map((item) => `${Array.isArray(item.loc) ? item.loc.slice(-1)[0] : 'request'}: ${item.msg || 'Invalid value'}`).join(' ');
  return fallback;
}

function setMessage(selector, message, tone = '') {
  const element = $(selector);
  element.textContent = message;
  element.dataset.tone = tone;
}

async function api(path, options = {}) {
  const response = await fetch(path, { headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try { message = errorMessage((await response.json()).detail, message); } catch (_) { /* keep fallback */ }
    throw new Error(message);
  }
  return response;
}

function setStep(step) {
  document.querySelectorAll('.step').forEach((element, index) => element.classList.toggle('active', index < step));
}

function showWhatsappMode(whatsapp) {
  const element = $('#whatsappMode');
  if (whatsapp.configured) {
    element.textContent = 'WhatsApp webhook connected';
    element.classList.remove('test');
  } else {
    element.textContent = 'Test inbox active · webhook ready';
    element.classList.add('test');
  }
}

async function loadConfig() {
  const data = await (await api('/api/config')).json();
  state.config = data;
  $('#savedRules').textContent = `V2 · ${data.saved_mapping_count} remembered rule${data.saved_mapping_count === 1 ? '' : 's'}`;
  $('#newColumnType').innerHTML = data.data_types.filter((type) => !['Ignore', 'Auto'].includes(type)).map((type) => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
  showWhatsappMode(data.whatsapp);
  return data;
}

function sampleText() {
  return `Party: Sharma Traders
Date: 07/09/2026
Material: Cement
Qty: 25 bags
Rate: ₹420
Total: ₹10,500
Payment Status: Pending

Customer: Gupta Hardware
Date: 07/09/2026
Product: Steel Rod
Quantity: 12 pieces
Price: 850
Amount: 10200
Payment Status: Paid
Mobile: +91 98765 43210

Verma Construction
30 bags cement rate 415 payment pending`;
}

function clearSourceMessage() {
  state.sourceMessageIds = [];
  state.sourceMessage = null;
  $('#sourceContext').classList.add('hidden');
  $('#sourceContext').textContent = '';
}

function showSourceMessage(message) {
  state.sourceMessageIds = [message.id];
  state.sourceMessage = message;
  const context = $('#sourceContext');
  context.textContent = `Prepared from inbox message #${message.id} · ${message.contact_name || message.sender} · ${message.sender}`;
  context.classList.remove('hidden');
}

function inboxSnippet(value) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, 180);
}

function renderInbox() {
  const summary = state.inboxSummary;
  $('#inboxSummary').innerHTML = ['all', 'new', 'opened', 'exported', 'ignored'].map((status) => `<span><b>${summary[status] || 0}</b>${escapeHtml(status)}</span>`).join('');
  const holder = $('#inboxList');
  if (!state.inbox.length) {
    holder.innerHTML = '<div class="empty-state">No messages match this view. Load the V2 demo messages to try the full inbox workflow.</div>';
    return;
  }
  holder.innerHTML = state.inbox.map((message) => `
    <article class="inbox-item">
      <div class="inbox-main">
        <div class="inbox-title"><strong>${escapeHtml(message.contact_name || message.sender)}</strong><span class="inbox-status status-${escapeHtml(message.status)}">${escapeHtml(message.status)}</span></div>
        <small>${escapeHtml(message.sender)} · ${escapeHtml(message.source)} · ${escapeHtml(message.received_at)}</small>
        <p>${escapeHtml(inboxSnippet(message.body))}</p>
      </div>
      <div class="inbox-item-actions">
        <button class="btn secondary" type="button" data-prepare-message="${message.id}">Use message</button>
        ${message.status !== 'ignored' ? `<button class="text-button" type="button" data-ignore-message="${message.id}">Ignore</button>` : ''}
      </div>
    </article>`).join('');
  holder.querySelectorAll('[data-prepare-message]').forEach((button) => button.addEventListener('click', () => prepareInboxMessage(Number(button.dataset.prepareMessage), button)));
  holder.querySelectorAll('[data-ignore-message]').forEach((button) => button.addEventListener('click', () => ignoreInboxMessage(Number(button.dataset.ignoreMessage))));
}

async function loadInbox() {
  const status = $('#inboxStatusFilter').value;
  const query = $('#inboxSearch').value.trim();
  const path = `/api/inbox?status=${encodeURIComponent(status)}&q=${encodeURIComponent(query)}&limit=50`;
  const data = await (await api(path)).json();
  state.inbox = data.messages;
  state.inboxSummary = data.summary;
  renderInbox();
}

async function seedDemoInbox() {
  const button = $('#seedInboxBtn');
  button.disabled = true;
  setMessage('#inboxMessage', 'Creating demo messages…');
  try {
    const data = await (await api('/api/inbox/demo', { method: 'POST', body: '{}' })).json();
    await loadInbox();
    setMessage('#inboxMessage', data.message, 'success');
  } catch (error) {
    setMessage('#inboxMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
}

async function ignoreInboxMessage(messageId) {
  if (!confirm('Ignore this message? It will remain in the audit trail but will be removed from active inbox views.')) return;
  try {
    await api(`/api/inbox/${messageId}/ignore`, { method: 'POST', body: '{}' });
    await loadInbox();
    setMessage('#inboxMessage', `Message #${messageId} ignored.`, 'success');
  } catch (error) {
    setMessage('#inboxMessage', error.message, 'error');
  }
}

function collectMappings() {
  return [...document.querySelectorAll('.mapping-row')].map((row) => ({
    source_field: row.dataset.field,
    target_column: row.querySelector('[data-column]').value,
    data_type: row.querySelector('[data-type]').value,
    categories: row.querySelector('[data-categories]').value.split(',').map((item) => item.trim()).filter(Boolean)
  }));
}

function preserveMappingEdits() {
  const current = new Map(collectMappings().map((mapping) => [mapping.source_field, mapping]));
  if (!current.size) return;
  state.suggestions = state.suggestions.map((suggestion) => ({ ...suggestion, ...(current.get(suggestion.source_field) || {}) }));
}

function renderMappings() {
  const holder = $('#mappingRows');
  holder.innerHTML = '';
  if (!state.suggestions.length) {
    holder.innerHTML = '<p class="empty-state">No fields were found to map.</p>';
    return;
  }
  for (const suggestion of state.suggestions) {
    const samples = state.records.map((record) => record[suggestion.source_field]).filter(Boolean);
    const row = document.createElement('div');
    row.className = 'mapping-row';
    row.dataset.field = suggestion.source_field;
    const columns = [...state.config.columns.map((column) => column.name), 'Ignore'];
    row.innerHTML = `
      <div class="source-field"><strong>${escapeHtml(suggestion.source_field)}${suggestion.reason === 'remembered' ? '<span class="remembered">REMEMBERED</span>' : ''}</strong><small>Example: ${escapeHtml(samples[0] || '—')}</small></div>
      <select data-column aria-label="Excel column for ${escapeHtml(suggestion.source_field)}">${columns.map((column) => `<option value="${escapeHtml(column)}" ${column === suggestion.target_column ? 'selected' : ''}>${escapeHtml(column)}</option>`).join('')}</select>
      <select data-type aria-label="Data type for ${escapeHtml(suggestion.source_field)}">${state.config.data_types.map((type) => `<option value="${escapeHtml(type)}" ${type === suggestion.data_type ? 'selected' : ''}>${escapeHtml(type)}</option>`).join('')}</select>
      <div class="category-box hidden" data-category-box><label>Allowed categories <small>Comma separated. Unknown values are flagged for review.</small></label><input data-categories value="${escapeHtml((suggestion.categories || []).join(', '))}" placeholder="Paid, Pending, Partial, Cancelled" /></div>`;
    const columnSelect = row.querySelector('[data-column]');
    const typeSelect = row.querySelector('[data-type]');
    const categoryBox = row.querySelector('[data-category-box]');
    const categoryInput = row.querySelector('[data-categories]');
    const columnInfo = () => state.config.columns.find((column) => column.name === columnSelect.value);
    const syncCategory = () => {
      categoryBox.classList.toggle('hidden', typeSelect.value !== 'Category');
      const column = columnInfo();
      if (typeSelect.value === 'Category' && !categoryInput.value.trim() && column?.categories?.length) categoryInput.value = column.categories.join(', ');
    };
    const applyColumnDefaults = () => {
      const column = columnInfo();
      if (columnSelect.value === 'Ignore') { typeSelect.value = 'Ignore'; categoryInput.value = ''; }
      else if (column) { typeSelect.value = column.data_type; if (column.data_type === 'Category') categoryInput.value = column.categories.join(', '); }
      syncCategory();
    };
    typeSelect.addEventListener('change', syncCategory);
    columnSelect.addEventListener('change', applyColumnDefaults);
    syncCategory();
    holder.appendChild(row);
  }
}

function renderReviewStatus() {
  const issueBox = $('#issuesBox');
  if (state.issues.length) {
    issueBox.classList.remove('hidden');
    issueBox.innerHTML = `<strong>${state.issues.length} value${state.issues.length === 1 ? '' : 's'} need attention</strong>${state.issues.slice(0, 15).map((issue) => `<br>Row ${issue.row}: <b>${escapeHtml(issue.source_field)}</b> → ${escapeHtml(issue.target_column)} — ${escapeHtml(issue.message)}`).join('')}`;
    $('#reviewBadge').textContent = `${state.issues.length} to review`;
    $('#reviewBadge').classList.add('warn');
  } else {
    issueBox.classList.add('hidden');
    issueBox.innerHTML = '';
    $('#reviewBadge').textContent = 'All checks passed';
    $('#reviewBadge').classList.remove('warn');
  }
}

function renderReview() {
  const issueKeys = new Set(state.issues.map((issue) => `${issue.row - 1}|${issue.target_column}`));
  const table = $('#reviewTable');
  table.innerHTML = `<thead><tr><th>#</th>${state.columns.map((column) => `<th>${escapeHtml(column)}</th>`).join('')}</tr></thead><tbody>${state.cleanRows.map((row, rowIndex) => `<tr><td class="row-number">${rowIndex + 1}</td>${state.columns.map((column) => `<td class="${issueKeys.has(`${rowIndex}|${column}`) ? 'cell-issue' : ''}"><input data-ri="${rowIndex}" data-col="${escapeHtml(column)}" value="${escapeHtml(row[column] ?? '')}" /></td>`).join('')}</tr>`).join('')}</tbody>`;
  table.querySelectorAll('input[data-ri]').forEach((input) => input.addEventListener('input', () => {
    const rowIndex = Number(input.dataset.ri);
    const column = input.dataset.col;
    state.cleanRows[rowIndex][column] = input.value;
    const before = state.issues.length;
    state.issues = state.issues.filter((issue) => !(issue.row - 1 === rowIndex && issue.target_column === column));
    input.closest('td').classList.remove('cell-issue');
    if (before !== state.issues.length) renderReviewStatus();
    setMessage('#exportMessage', 'Edits must be re-checked before export.');
  }));
  renderReviewStatus();
}

function buildReviewRules(mappings, columns) {
  return columns.map((column) => {
    const mapping = mappings.find((item) => item.target_column === column && item.data_type !== 'Ignore');
    const configured = state.config.columns.find((item) => item.name === column);
    return { column, data_type: mapping?.data_type || configured?.data_type || 'Text', categories: mapping?.categories?.length ? mapping.categories : (configured?.categories || []) };
  });
}

async function recheckReviewedValues() {
  if (!state.cleanRows.length) return false;
  const data = await (await api('/api/review/validate', { method: 'POST', body: JSON.stringify({ rows: state.cleanRows, columns: state.columns, rules: state.rules }) })).json();
  state.cleanRows = data.rows;
  state.issues = data.issues;
  renderReview();
  return !data.issues.length;
}

async function applyParsedData(data, options = {}) {
  state.records = data.records;
  state.suggestions = data.suggestions;
  state.cleanRows = [];
  state.columns = [];
  state.issues = [];
  state.rules = [];
  if (options.sourceMessage) showSourceMessage(options.sourceMessage); else clearSourceMessage();
  if (data.raw_text) $('#rawInput').value = data.raw_text;
  await loadConfig();
  renderMappings();
  $('#mappingCard').classList.remove('hidden');
  $('#reviewCard').classList.add('hidden');
  setMessage('#importMessage', `Found ${data.records.length} record(s) and ${data.fields.length} field(s).`, 'success');
  setStep(3);
  $('#mappingCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function prepareInboxMessage(messageId, button) {
  button.disabled = true;
  setMessage('#inboxMessage', `Preparing message #${messageId}…`);
  try {
    const data = await (await api(`/api/inbox/${messageId}/prepare`, { method: 'POST', body: '{}' })).json();
    await applyParsedData(data, { sourceMessage: data.source_message });
    await loadInbox();
    setMessage('#inboxMessage', `Message #${messageId} is ready for mapping.`, 'success');
  } catch (error) {
    setMessage('#inboxMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
}

$('#seedInboxBtn').addEventListener('click', seedDemoInbox);
$('#refreshInboxBtn').addEventListener('click', () => loadInbox().catch((error) => setMessage('#inboxMessage', error.message, 'error')));
$('#inboxStatusFilter').addEventListener('change', () => loadInbox().catch((error) => setMessage('#inboxMessage', error.message, 'error')));
let inboxSearchTimer;
$('#inboxSearch').addEventListener('input', () => {
  clearTimeout(inboxSearchTimer);
  inboxSearchTimer = setTimeout(() => loadInbox().catch((error) => setMessage('#inboxMessage', error.message, 'error')), 250);
});

$('#sampleBtn').addEventListener('click', () => {
  clearSourceMessage();
  $('#rawInput').value = sampleText();
  setMessage('#importMessage', 'Example loaded. Select Extract fields to continue.');
});

$('#extractBtn').addEventListener('click', async () => {
  const text = $('#rawInput').value.trim();
  if (!text) { setMessage('#importMessage', 'Paste some data first.', 'error'); return; }
  const button = $('#extractBtn');
  button.disabled = true;
  setMessage('#importMessage', 'Extracting…');
  try {
    const data = await (await api('/api/parse', { method: 'POST', body: JSON.stringify({ text }) })).json();
    await applyParsedData(data);
  } catch (error) {
    setMessage('#importMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

$('#addColumnBtn').addEventListener('click', async () => {
  const input = $('#newColumnInput');
  const name = input.value.trim();
  if (!name) { setMessage('#mappingMessage', 'Enter a column name.', 'error'); return; }
  preserveMappingEdits();
  const button = $('#addColumnBtn');
  button.disabled = true;
  try {
    await api('/api/columns', { method: 'POST', body: JSON.stringify({ name, data_type: $('#newColumnType').value, categories: [] }) });
    input.value = '';
    await loadConfig();
    renderMappings();
    setMessage('#mappingMessage', `Added “${name}”.`, 'success');
  } catch (error) {
    setMessage('#mappingMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

$('#newColumnInput').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') { event.preventDefault(); $('#addColumnBtn').click(); }
});

$('#clearRulesBtn').addEventListener('click', async () => {
  if (!confirm('Clear all remembered field mappings? Your Excel columns will stay.')) return;
  const button = $('#clearRulesBtn');
  button.disabled = true;
  try {
    await api('/api/mappings', { method: 'DELETE', body: '{}' });
    state.suggestions = state.suggestions.map((suggestion) => ({ ...suggestion, reason: 'suggested' }));
    await loadConfig();
    renderMappings();
    setMessage('#mappingMessage', 'Remembered mappings cleared.', 'success');
  } catch (error) {
    setMessage('#mappingMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

$('#reviewBtn').addEventListener('click', async () => {
  preserveMappingEdits();
  const mappings = collectMappings();
  if (!mappings.length) { setMessage('#mappingMessage', 'Extract fields before opening the review.', 'error'); return; }
  const button = $('#reviewBtn');
  button.disabled = true;
  setMessage('#mappingMessage', 'Validating…');
  try {
    await api('/api/mappings/save', { method: 'POST', body: JSON.stringify({ mappings }) });
    const data = await (await api('/api/validate', { method: 'POST', body: JSON.stringify({ records: state.records, mappings }) })).json();
    state.cleanRows = data.rows;
    state.columns = data.columns;
    state.issues = data.issues;
    state.rules = buildReviewRules(mappings, data.columns);
    renderReview();
    await loadConfig();
    $('#reviewCard').classList.remove('hidden');
    setMessage('#mappingMessage', 'Mapping saved. Review any highlighted cells before export.', 'success');
    setMessage('#exportMessage', state.issues.length ? 'Correct the flagged values, then re-check.' : 'Ready to export.');
    setStep(4);
    $('#reviewCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    setMessage('#mappingMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

$('#recheckBtn').addEventListener('click', async () => {
  const button = $('#recheckBtn');
  button.disabled = true;
  setMessage('#exportMessage', 'Checking edited values…');
  try {
    const valid = await recheckReviewedValues();
    setMessage('#exportMessage', valid ? 'All checks passed. Ready to export.' : 'Fix the highlighted values, then re-check.', valid ? 'success' : 'error');
  } catch (error) {
    setMessage('#exportMessage', error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

$('#exportBtn').addEventListener('click', async () => {
  if (!state.cleanRows.length) return;
  const button = $('#exportBtn');
  button.disabled = true;
  button.textContent = 'Checking…';
  setMessage('#exportMessage', 'Checking edited values…');
  try {
    if (!await recheckReviewedValues()) { setMessage('#exportMessage', 'Fix the highlighted values before exporting.', 'error'); return; }
    button.textContent = 'Creating Excel…';
    const response = await api('/api/export', { method: 'POST', body: JSON.stringify({ rows: state.cleanRows, columns: state.columns, filename: $('#filenameInput').value || 'whatsapp_excel_import.xlsx', message_ids: state.sourceMessageIds }) });
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const match = (response.headers.get('content-disposition') || '').match(/filename="?([^";]+)"?/);
    link.href = url;
    link.download = match?.[1] || 'whatsapp_excel_import.xlsx';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    await loadInbox();
    setMessage('#exportMessage', 'Excel file created and source message marked exported.', 'success');
  } catch (error) {
    setMessage('#exportMessage', error.message, 'error');
  } finally {
    button.disabled = false;
    button.textContent = 'Download Excel (.xlsx)';
  }
});

document.querySelectorAll('[data-jump]').forEach((button) => button.addEventListener('click', () => {
  const target = document.getElementById(button.dataset.jump);
  if (!target || target.classList.contains('hidden')) { setMessage('#importMessage', 'Complete the previous step first.', 'error'); return; }
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}));

Promise.all([loadConfig(), loadInbox()]).catch((error) => {
  $('#savedRules').textContent = 'Server unavailable';
  setMessage('#inboxMessage', `Could not connect to the local server: ${error.message}`, 'error');
});
